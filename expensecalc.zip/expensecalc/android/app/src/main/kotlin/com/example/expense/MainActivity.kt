package com.example.expense

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
